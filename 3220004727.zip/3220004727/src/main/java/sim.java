import java.math.BigInteger;
import java.util.List;

public interface sim {

	 BigInteger simHash();
	 BigInteger hash(String source);
	 int hammingDistance(simhash other);
	 double getDistance(String str1, String str2);
	 List subByDistance(simhash simHashImpl, int distance);

}
