import java.io.File;
import java.io.*;

public class rw {

	public String readString(String FI){
        int len=0;
        StringBuffer str=new StringBuffer("");
        File file = new File(FI);
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String line=null;
            while((line=bufferedReader.readLine())!=null){
                if (len!=0){
                    str.append("\r\n"+line);
                }else {
                    str.append(line);
                }
                len++;
            }
            bufferedReader.close();
            fileInputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return str.toString();
    }

    public static void main(String[] args) {
        rw fileInput = new rw();
        String s = fileInput.readString("D:\\Eclipse\\3220004727\\dif\\orig.txt");
        System.out.println(s);
    }


}
