import org.junit.Test;

public class test {
	String origin="D:\\Eclipse\\3220004727\\dif\\orig.txt";
	 String[] s={
		        "D:\\Eclipse\\3220004727\\dif\\orig_0.8_add.txt",
		        "D:\\Eclipse\\3220004727\\dif\\orig_0.8_del.txt",
		        "D:\\Eclipse\\3220004727\\dif\\orig_0.8_dis_1.txt",
		        "D:\\Eclipse\\3220004727\\dif\\orig_0.8_dis_10.txt",
		        "D:\\Eclipse\\3220004727\\dif\\orig_0.8_dis_15.txt"};

    @org.junit.Test
    public void addTest(){
        rw fileInput = new rw();
        simhash hash1 = new simhash(fileInput.readString(origin), 64);
        hash1.subByDistance(hash1, 3);
        simhash hash2 = new simhash(fileInput.readString(s[0]), 64);
        hash2.subByDistance(hash2, 3);
        double distance = hash1.getDistance(hash1.getStrSimHash(),hash2.getStrSimHash());
        System.out.println("��������ԭ�����ƶ�Ϊ��"+(100-distance*100/128)+"%\n");
    }

    @org.junit.Test
    public void delTest(){
    	rw fileInput = new rw();
    	simhash hash1 = new simhash(fileInput.readString(origin), 64);
        hash1.subByDistance(hash1, 3);
        simhash hash2 = new simhash(fileInput.readString(s[1]), 64);
        hash2.subByDistance(hash2, 3);
        double distance = hash1.getDistance(hash1.getStrSimHash(),hash2.getStrSimHash());
        System.out.println("��������ԭ�����ƶ�Ϊ��"+(100-distance*100/128)+"%\n");
    }

    @org.junit.Test
    public void dis_1Test(){
        rw fileInput = new rw();
        simhash hash1 = new simhash(fileInput.readString(origin), 64);
        hash1.subByDistance(hash1, 3);
        simhash hash2 = new simhash(fileInput.readString(s[2]), 64);
        hash2.subByDistance(hash2, 3);
        double distance = hash1.getDistance(hash1.getStrSimHash(),hash2.getStrSimHash());
        System.out.println("��������ԭ�����ƶ�Ϊ��"+(100-distance*100/128)+"%\n");
    }

    @org.junit.Test
    public void dis_10Test(){
        rw fileInput = new rw();
        simhash hash1 = new simhash(fileInput.readString(origin), 64);
        hash1.subByDistance(hash1, 3);
        simhash hash2 = new simhash(fileInput.readString(s[3]), 64);
        hash2.subByDistance(hash2, 3);
        double distance = hash1.getDistance(hash1.getStrSimHash(),hash2.getStrSimHash());
        System.out.println("��������ԭ�����ƶ�Ϊ��"+(100-distance*100/128)+"%\n");
    }

    @org.junit.Test
    public void dis_15Test(){
        rw fileInput = new rw();
        simhash hash1 = new simhash(fileInput.readString(origin), 64);
        hash1.subByDistance(hash1, 3);
        simhash hash2 = new simhash(fileInput.readString(s[4]), 64);
        hash2.subByDistance(hash2, 3);
        double distance = hash1.getDistance(hash1.getStrSimHash(),hash2.getStrSimHash());
        System.out.println("��������ԭ�����ƶ�Ϊ��"+(100-distance*100/128)+"%\n");
    }

}
